var indexSectionsWithContent =
{
  0: "abcefglmnoprstv~",
  1: "aefmnprtv",
  2: "abcefglmnprstv~",
  3: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Funções",
  3: "Amigas"
};

