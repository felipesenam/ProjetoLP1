var searchData=
[
  ['remanimal',['remAnimal',['../classPetFera.html#ab9a44d9cb270ba9a09bb2a28b96ca9ed',1,'PetFera::remAnimal()'],['../classPetFera.html#aedb4319b085408a241621adccf9db86c',1,'PetFera::remAnimal(int)']]],
  ['remfunc',['remFunc',['../classPetFera.html#a850d3e355371bf9af64a39730cc17f32',1,'PetFera']]],
  ['reptil',['Reptil',['../classReptil.html',1,'Reptil'],['../classReptil.html#a8d4e391e335678b7ed64eda95e050553',1,'Reptil::Reptil()'],['../classReptil.html#ab0be07f29631263b4489563409458683',1,'Reptil::Reptil(std::string especie, short id, char ameacadaExtincao, char perigoso, std::string NF)']]],
  ['reptilexotico',['ReptilExotico',['../classReptilExotico.html',1,'ReptilExotico'],['../classReptilExotico.html#ab34ea84980c9dabf315e34399c799279',1,'ReptilExotico::ReptilExotico()']]],
  ['reptilnativo',['ReptilNativo',['../classReptilNativo.html',1,'ReptilNativo'],['../classReptilNativo.html#a48c7dbd37a7464ec4059e76169708efc',1,'ReptilNativo::ReptilNativo()']]],
  ['run',['run',['../classPetFera.html#a48b0c975be63743a8ea6cb783af1aa61',1,'PetFera']]]
];
