var searchData=
[
  ['nativo',['Nativo',['../classNativo.html',1,'Nativo'],['../classNativo.html#a8d3f58a78b3a365376059e2d9916b78b',1,'Nativo::Nativo()']]]
];
