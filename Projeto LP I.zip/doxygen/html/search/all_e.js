var searchData=
[
  ['veterinario',['Veterinario',['../classVeterinario.html',1,'Veterinario'],['../classVeterinario.html#af8dc5f6f77bf8c70dd94d54766764134',1,'Veterinario::Veterinario()'],['../classVeterinario.html#a303dd0f39004e8b1794d181bd1448676',1,'Veterinario::Veterinario(std::string, short, Status, std::string)']]]
];
