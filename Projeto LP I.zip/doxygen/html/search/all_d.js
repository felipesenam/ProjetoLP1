var searchData=
[
  ['tratador',['Tratador',['../classTratador.html',1,'Tratador'],['../classTratador.html#a4339bfc1e32968609401440338eeba20',1,'Tratador::Tratador()'],['../classTratador.html#a5f6d06d75da0324dbee7e7f7cc98ae66',1,'Tratador::Tratador(std::string, short, Status, Seguranca)']]]
];
