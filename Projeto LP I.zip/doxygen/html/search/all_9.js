var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classAnimal.html#a85149e614ed340f45b5329cbc893f8f4',1,'Animal::operator&lt;&lt;()'],['../classFuncionario.html#a59b7caf4b9518de363ab491862052acb',1,'Funcionario::operator&lt;&lt;()']]]
];
