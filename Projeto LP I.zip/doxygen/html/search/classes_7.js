var searchData=
[
  ['tratador',['Tratador',['../classTratador.html',1,'']]]
];
