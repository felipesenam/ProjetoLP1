var searchData=
[
  ['buscafunc',['buscaFunc',['../classPetFera.html#a068fe816d47ba3194c13e20fedcc8ea3',1,'PetFera']]],
  ['buscaranim',['buscarAnim',['../classPetFera.html#ac918c3cbd49d5249c6e614b24b132870',1,'PetFera']]]
];
