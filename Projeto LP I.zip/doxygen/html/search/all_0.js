var searchData=
[
  ['altanimal',['altAnimal',['../classPetFera.html#aaf345645dfba2a1708c3fa0323f4d0df',1,'PetFera']]],
  ['alttrat',['altTrat',['../classPetFera.html#af7a85e9528bb298a3a6c0432d9dbda2b',1,'PetFera']]],
  ['altvetr',['altVetr',['../classPetFera.html#a8afaea20bf9f2d7aa282fff2d0744c8c',1,'PetFera']]],
  ['anfibio',['Anfibio',['../classAnfibio.html',1,'Anfibio'],['../classAnfibio.html#a91fd9b91b9124ab41ea9e9c9bb013476',1,'Anfibio::Anfibio()'],['../classAnfibio.html#a28589184d89e13b9f85cd5acac8f8310',1,'Anfibio::Anfibio(std::string especie, short id, char ameacadaExtincao, char perigoso, std::string NF)']]],
  ['anfibioexotico',['AnfibioExotico',['../classAnfibioExotico.html',1,'AnfibioExotico'],['../classAnfibioExotico.html#a13425953e703854349e1c0f9ced330e9',1,'AnfibioExotico::AnfibioExotico()']]],
  ['anfibionativo',['AnfibioNativo',['../classAnfibioNativo.html',1,'AnfibioNativo'],['../classAnfibioNativo.html#af5dc59647ea725670fec8e4f8cd0da72',1,'AnfibioNativo::AnfibioNativo()']]],
  ['animal',['Animal',['../classAnimal.html',1,'Animal'],['../classAnimal.html#a1e726a49ec952443190ac62dad22353c',1,'Animal::Animal()'],['../classAnimal.html#a846678815c408de11dff5987fd111d3c',1,'Animal::Animal(std::string especie, short id, char ameacadaExtincao, char perigoso, std::string NF)']]],
  ['aptto',['aptto',['../classTratador.html#abdd36c87f52aef7a2e4b98800806efe9',1,'Tratador']]],
  ['ave',['Ave',['../classAve.html',1,'Ave'],['../classAve.html#a31bc97c3258df566381300c8b9abc73a',1,'Ave::Ave()'],['../classAve.html#a4b924b8618f434cf685d170fef4a99a6',1,'Ave::Ave(std::string especie, short id, char ameacadaExtincao, char perigoso, std::string NF)']]],
  ['aveexotico',['AveExotico',['../classAveExotico.html',1,'AveExotico'],['../classAveExotico.html#a4a6817c8e2b9b7f7a0bd94b845d77c12',1,'AveExotico::AveExotico()']]],
  ['avenativo',['AveNativo',['../classAveNativo.html',1,'AveNativo'],['../classAveNativo.html#a7f3e45924136573a3e423e59ae8acc95',1,'AveNativo::AveNativo()']]]
];
