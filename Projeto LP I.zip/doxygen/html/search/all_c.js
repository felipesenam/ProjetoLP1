var searchData=
[
  ['setameacadaextincao',['setAmeacadaExtincao',['../classAnimal.html#a9fe42fa16c1f457f3ec560860391a32c',1,'Animal']]],
  ['setcrmv',['setCRMV',['../classVeterinario.html#aa316acc3cee917bdef76a299e2f90dd7',1,'Veterinario']]],
  ['setespecie',['setEspecie',['../classAnimal.html#a45ca4cf1146d8dac0600a8092874e645',1,'Animal']]],
  ['setnf',['setNF',['../classAnimal.html#a51dfc4058680f793a7960e4d7ceaec7f',1,'Animal']]],
  ['setnome',['setNome',['../classFuncionario.html#a32e01bd23e422ab7598cd04dac51eb82',1,'Funcionario']]],
  ['setperigoso',['setPerigoso',['../classAnimal.html#a537f0bbf75097f725691737d1260a680',1,'Animal']]],
  ['setseguranca',['setSeguranca',['../classTratador.html#adbf61d3bbeed7bbcd7baa948a6e6d379',1,'Tratador']]],
  ['setstatus',['setStatus',['../classFuncionario.html#ace32735600beb134dff96c362972632b',1,'Funcionario']]],
  ['settratador',['setTratador',['../classAnimal.html#af6d9786fbfc88fe4fa4dd095f0d4e35a',1,'Animal']]],
  ['setveterinario',['setVeterinario',['../classAnimal.html#ad408646bb07611e4dc1e52c3b5b3d90a',1,'Animal']]]
];
