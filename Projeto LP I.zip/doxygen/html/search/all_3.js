var searchData=
[
  ['exotico',['Exotico',['../classExotico.html',1,'Exotico'],['../classExotico.html#a72ec157840147a3bc913d173dbf06e82',1,'Exotico::Exotico()']]]
];
